package models;

public enum ClassAnimal {
    HORSE,
    DONKEY,
    CAMEL,
    CAT,
    DOG,
    HAMSTER,
    NONE

}

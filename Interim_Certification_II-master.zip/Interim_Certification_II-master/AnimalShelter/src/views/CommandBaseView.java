package views;

public enum CommandBaseView {
    NONE,
    CREATE,
    GETCOM,
    NEWCOM,
    FINDID,
    EXIT
}
